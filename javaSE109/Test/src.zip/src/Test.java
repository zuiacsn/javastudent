public class Test {
    public static void main(String[] args) {
        Main main = new Main();
        main.printMedalTable();
        main.addChinaGold();
        main.addGermanyMedals();
        main.printTeamsWithNineGold();
        main.printIcelandMedals();
    }
}
